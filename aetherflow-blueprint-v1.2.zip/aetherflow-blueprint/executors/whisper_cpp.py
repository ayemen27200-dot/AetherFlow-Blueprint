"""Local whisper.cpp transcription executor; implementation is tracked by the related Dossier."""

from __future__ import annotations
from typing import Any, Callable
from .base import Executor


class WhisperCppExecutor(Executor):
    def run(self, job_spec: dict[str, Any], on_progress: Callable[[float], None]) -> dict[str, Any]:
        del job_spec, on_progress
        raise NotImplementedError("Executor not implemented; see D3/D4 specifications")
